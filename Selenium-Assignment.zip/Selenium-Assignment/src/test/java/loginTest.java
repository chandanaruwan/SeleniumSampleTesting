
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.Assertion;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

    public class loginTest {
        loginPage loginPage = new loginPage();
        homePage homePage = new homePage();

        @BeforeMethod
        public void preCondition() {
            loginPage.pageLoad("Chrome", "https://www.saucedemo.com/");

        }

        @Test
        public void testLogin() {
            loginPage.loginPage("standard_user", "secret_sauce");
            Assert.assertEquals(driverTest.driver.getTitle(), "Swag Labs");

            /*String url = driverTest.driver.getCurrentUrl();
             assertEquals("https://www.saucedemo.com/inventory.html", url); */



        }

}


