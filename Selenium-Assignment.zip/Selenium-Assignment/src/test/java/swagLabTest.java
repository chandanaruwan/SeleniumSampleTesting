import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

    public class swagLabTest {
        loginPage loginPage = new loginPage();
        homePage homePage = new homePage();
        productPage productPage = new productPage();
        checkOutPage checkOutPage = new checkOutPage();
        overViewPage overViewPage=new overViewPage();
        cartPage cartPage = new cartPage();


        @BeforeClass
        public void preCondition() {
            loginPage.pageLoad("Chrome", "https://www.saucedemo.com/");

        }

        @Test
        public void verifyNavigationToProductPage() {
            loginPage.loginPage("standard_user", "secret_sauce");
            Assert.assertEquals(driverTest.driver.getTitle(), "Swag Labs");
             /* String url = driverTest.driver.getCurrentUrl();
             assertEquals("https://www.saucedemo.com/inventory.html", url); */

        }

        @Test(priority = 1)
        public void verifyNavigationToCartPage() {
            homePage.addtoCart();
            homePage.navigrateToCart();
            Assert.assertEquals(cartPage.viewList(),"Sauce Labs Bolt T-Shirt");


        }

        @Test(priority = 2)
        public void VerifyCheckoutDetailsPage(){
            productPage.clickCheckout();
            checkOutPage.checkoutPage("Chandana","Diyunuge","60406");
            checkOutPage.clickContinue();
            Assert.assertEquals(checkOutPage.checkAddInformation(), "FINISH");

        }

        @Test(priority = 3)
        public void VerifyCartTotal(){
            Assert.assertEquals(overViewPage.checkLogTotal(),"Total: $49.66");
            overViewPage.clickFinish();
            Assert.assertEquals(overViewPage.checkComplete(), "THANK YOU FOR YOUR ORDER");
        }


        @AfterClass
        public void postCondition(){

            //loginPage.closeBrowser();
        }

    }



