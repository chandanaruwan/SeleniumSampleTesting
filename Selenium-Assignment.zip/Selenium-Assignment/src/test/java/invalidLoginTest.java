import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class invalidLoginTest {

    loginPage loginPage = new loginPage();
    homePage homePage = new homePage();

    @BeforeMethod
    public void preCondition(){
        loginPage.pageLoad("Chrome", "https://www.saucedemo.com/");

    }
    @Test
    public void testLoginInvalidUser(){
        loginPage.loginPage("sms","secret_sauce");}
    @Test(dependsOnMethods = "testLoginInvalidUser",alwaysRun = true)

    public void testLoginInvalidPassword(){
        loginPage.loginPage("standard_user","ss");}
    @Test(dependsOnMethods = "testLoginInvalidPassword",alwaysRun = true)

    public void testLoginBlankUser(){
        loginPage.loginPage("","secret_sauce");}
    @Test(dependsOnMethods = "testLoginBlankUser",alwaysRun = true)

    public void testLoginBlankPassword(){
        loginPage.loginPage("standard_user","");}
    @Test(dependsOnMethods = "testLoginBlankPassword",alwaysRun = true)

    @AfterMethod
    public void closeCondition(){
        loginPage.closeBrowser();
    }

}

