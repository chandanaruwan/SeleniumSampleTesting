import org.openqa.selenium.By;

public class overViewPage extends driverTest{

    By lblcheckout = By.className("complete-header")  ;
    By txtTotal=By.className("summary_total_label");
    By finishButton=By.id("finish");

    public String checkLogTotal() {

        String value = driver.findElement(txtTotal).getText();
        return value;
    }

    public String checkComplete() {
        String value = driver.findElement(lblcheckout).getText();
        System.out.println("checkout completed");
        return value;
    }
    public void clickFinish(){
        driver.findElement(finishButton).click();
        System.out.println("Successfully order placed");

    }
}