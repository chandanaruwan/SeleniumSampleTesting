import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class driverTest {

    static WebDriver driver;

    public void setproperties(String driverType, String url) {

        if (driverType == "Chrome") {
            System.setProperty("webdriver.chrome.driver", "res/chromedriver.exe");
            driver = new ChromeDriver();
        }
        if (driverType == "Firefox") {
            //System.setProperty("webdriver.gecko.driver", "res/geckodriver.exe");
            driver = new FirefoxDriver();
        }

        driver.navigate().to(url);
        // driver.manage().window().maximize();




    }
}