import org.openqa.selenium.By;


public class homePage extends driverTest{
    By lblLogo = By.className("title");
    By addCartButton1=By.name("add-to-cart-sauce-labs-backpack");
    By addCartButton2=By.name("add-to-cart-sauce-labs-bolt-t-shirt");
    By clickCart=By.className("shopping_cart_link");


    public String checkLogHome(){
        String value = driver.findElement(lblLogo).getText();
        System.out.println("Inventy Page Loaded");
        return value;
    }

    public void addtoCart(){
        driver.findElement(addCartButton1).click();
        driver.findElement(addCartButton2).click();
        System.out.println("Add items to the cart");
    }

    public void navigrateToCart(){
        driver.findElement(clickCart).click();
        System.out.println("Navigate to the cart page");
    }


}

