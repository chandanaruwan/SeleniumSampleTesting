import org.openqa.selenium.By;

public class checkOutPage extends driverTest{

    By txtFirstName=By.name("firstName");
    By txtLastName=By.name("lastName");
    By txtPostalCode=By.name("postalCode");
    By continueButton=By.name("continue");
    By VerifyCheckOut =By.id("finish");

    By viewlist = By.className("inventory_item_name")  ;

    public void checkoutPage(String firstName,String lastName,String postalCode){
        driver.findElement(txtFirstName).sendKeys(firstName);
        driver.findElement(txtLastName).sendKeys(lastName);
        driver.findElement(txtPostalCode).sendKeys(postalCode);

    }

    public void clickContinue(){
        driver.findElement(continueButton).click();
        System.out.println("Navigate to the checkout overview page");
    }


    public String viewList() {
        String value = driver.findElement(viewlist).getText();
        System.out.println("Successfully added");
        return value;
    }

    public String checkAddInformation(){
        String value = driver.findElement(VerifyCheckOut).getText();
        System.out.println("Successfully Enter your information ");
        return value;
    }

}