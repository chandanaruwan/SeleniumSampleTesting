import org.openqa.selenium.By;

public class cartPage extends driverTest{


    By viewlist = By.id("item_1_title_link")  ;


    public String viewList() {
        String value = driver.findElement(viewlist).getText();
        System.out.println("Successfully added");
        return value;
    }
}

