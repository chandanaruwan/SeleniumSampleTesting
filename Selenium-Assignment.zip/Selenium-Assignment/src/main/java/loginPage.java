import org.openqa.selenium.By;

public class loginPage extends driverTest{
    By txtUserId=By.name("user-name");
    By txtPassword=By.name("password");
    By btnLogin=By.name("login-button");

    public void pageLoad(String dType , String url){
        setproperties(dType,url);


    }
    public void loginPage(String Username , String Password){
        driver.findElement(txtUserId).sendKeys(Username);
        driver.findElement(txtPassword).sendKeys(Password);
        driver.findElement(btnLogin).click();

    }
    public void closeBrowser(){
        driver.close();

    }

    public void refreshBrowser(){
        driver.navigate().refresh();
    }

}