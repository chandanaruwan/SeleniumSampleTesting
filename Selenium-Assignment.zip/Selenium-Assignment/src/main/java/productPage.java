import org.openqa.selenium.By;

public class productPage extends driverTest {

    //By productName=By.className("inventory_details_name large_size");
    By productName=By.className("inventory_item_name");
    By checkoutButton=By.name("checkout");

    public  String checkProduct() {

        String value = driver.findElement(productName).getText();
        //   String value1 = driver.findElement(productName).getText();
        System.out.println("Sauce Labs Backpack item has been added to the cart");
        return value;

    }


    public  void clickCheckout(){

        driver.findElement(checkoutButton).click();
    }

}
